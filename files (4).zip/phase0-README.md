# Phase 0 — data layer

The first deliverable of the consolidation: one schema replacing seven
demonstration data models, and the authorisation matrix those demonstrations
proved.

| File | What it is |
|---|---|
| `prisma/schema.prisma` | The unified data model — 48 models, 34 enums, 55 foreign-key relations |
| `prisma/seed-permissions.ts` | 16 roles × 72 permissions, transcribed from the built modules |
| `check-schema.js` | Structural validator (relations, back-references, enum usage) |

## Running it

```bash
npm install prisma @prisma/client
npx prisma validate                 # full validation
npx prisma migrate dev --name init  # create the database
npx prisma studio                   # inspect it
```

`check-schema.js` was written because the Prisma CLI was unavailable in the
authoring environment. It catches hand-written schema errors — a relation
pointing at a missing model, a one-sided relation, an undeclared enum, an index
on a field that does not exist. Keep it or drop it once `prisma validate` runs
in CI; it is not a replacement.

## The five decisions this schema makes

The demonstrations could not settle these, because browser storage does not
force the question. Each is marked `>>> DECISION` in the schema.

1. **One append-only audit table** for the whole system, rather than one per
   module. "Everything that touched this patient" becomes a single query, and
   history survives a member of staff leaving.

2. **Rate cards are versioned, not overwritten.** An invoice raised today must
   be defensible against the rates that applied on the day of travel.

3. **Sealed sections are separate tables.** Clinical and safeguarding data live
   in `PatientClinical` and `PatientSafeguarding`, so they can simply not be
   selected for a role that lacks the permission — rather than being fetched
   and hidden in the browser, which is what the demonstration had to do. Staff
   occupational health is split the same way and for the same reason.

4. **Status history is rows, not a map.** The demos kept `status: timestamp`,
   which cannot record who, from where, or the same status twice.
   `BookingStatusEvent` carries the operator and the position.

5. **Compliance is rows, not columns.** A new mandatory check becomes a data
   change rather than a migration, and one query answers "who and what is
   blocked, and why" across people and vehicles alike.

Two further points worth noting: money is `Decimal`, never `Float`; and
`InvoiceLine.bookingId` is `@unique`, which makes double-billing a database
constraint rather than an application check.

## What this does not include

Migrations beyond the initial one, the Next.js application, the server
functions that will hold the pricing and allocation rules, and the seed data
for development. Those are the rest of Phase 0.

## Open questions carried forward

Three are recorded at the foot of `seed-permissions.ts` — the status of the
Booking Administrator role, whether Finance should see payroll detail, and how
long a break-glass grant should last. None blocks the schema; all should be
settled before the authorisation layer is built.
