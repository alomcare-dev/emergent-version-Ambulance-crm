/* Structural check for schema.prisma.
   Not a substitute for `prisma validate`, but catches the errors that actually
   happen when writing a schema by hand: a relation pointing at a model that
   doesn't exist, a one-sided relation with no back-reference, a field typed as
   an enum that was never declared, a relation scalar with no matching field. */

const fs = require("fs");
const src = fs.readFileSync(__dirname + "/prisma/schema.prisma", "utf8");

/* ---- strip comments ---- */
const clean = src.split("\n").map(l => l.replace(/\/\/.*$/, "")).join("\n");

/* ---- collect blocks ---- */
const models = {}, enums = new Set();
const blockRe = /^(model|enum)\s+(\w+)\s*\{([\s\S]*?)^\}/gm;
let m;
while ((m = blockRe.exec(clean))) {
  const [, kind, name, bodyRaw] = m;
  if (kind === "enum") { enums.add(name); continue; }
  const fields = [];
  bodyRaw.split("\n").forEach(line => {
    const t = line.trim();
    if (!t || t.startsWith("@@")) return;
    const fm = t.match(/^(\w+)\s+([A-Za-z_]\w*)(\[\])?(\?)?(.*)$/);
    if (!fm) return;
    const [, fname, ftype, list, opt, rest] = fm;
    fields.push({ name: fname, type: ftype, list: !!list, optional: !!opt, attrs: rest || "" });
  });
  models[name] = { name, fields, body: bodyRaw };
}

const SCALARS = new Set(["String","Int","BigInt","Float","Decimal","Boolean","DateTime","Json","Bytes","Unsupported"]);
const errors = [], warnings = [];

const modelNames = Object.keys(models);
console.log(`Parsed ${modelNames.length} models, ${enums.size} enums.\n`);

/* ---- 1. every field type resolves ---- */
for (const mo of Object.values(models)) {
  for (const f of mo.fields) {
    if (SCALARS.has(f.type) || enums.has(f.type) || models[f.type]) continue;
    errors.push(`${mo.name}.${f.name}: unknown type "${f.type}"`);
  }
}

/* ---- 2. relation fields have a back-reference on the other side ---- */
for (const mo of Object.values(models)) {
  for (const f of mo.fields) {
    if (!models[f.type]) continue;                    // not a relation
    const other = models[f.type];
    const nameAttr = f.attrs.match(/@relation\("([^"]+)"/);
    const relName = nameAttr ? nameAttr[1] : null;

    const back = other.fields.filter(of => {
      if (of.type !== mo.name) return false;
      const on = of.attrs.match(/@relation\("([^"]+)"/);
      const oName = on ? on[1] : null;
      return relName ? oName === relName : !oName;
    });

    if (back.length === 0) {
      errors.push(`${mo.name}.${f.name} -> ${f.type}: no back-reference on ${f.type}` +
        (relName ? ` for named relation "${relName}"` : ""));
    } else if (back.length > 1 && !relName) {
      errors.push(`${mo.name}.${f.name} -> ${f.type}: ${back.length} candidate back-references; needs a named relation`);
    }
  }
}

/* ---- 3. every `fields: [x]` scalar exists on the model ---- */
for (const mo of Object.values(models)) {
  const names = new Set(mo.fields.map(f => f.name));
  const re = /@relation\([^)]*fields:\s*\[([^\]]+)\]/g;
  let r;
  while ((r = re.exec(mo.body))) {
    r[1].split(",").map(s => s.trim()).forEach(fk => {
      if (fk && !names.has(fk)) errors.push(`${mo.name}: @relation fields references missing scalar "${fk}"`);
    });
  }
}

/* ---- 4. exactly one side of each relation holds the foreign key ---- */
for (const mo of Object.values(models)) {
  for (const f of mo.fields) {
    if (!models[f.type] || f.list) continue;
    const hasFk = /fields:\s*\[/.test(f.attrs);
    const other = models[f.type];
    const nameAttr = f.attrs.match(/@relation\("([^"]+)"/);
    const relName = nameAttr ? nameAttr[1] : null;
    const back = other.fields.find(of => {
      if (of === f) return false;                     // never match a field against itself
      if (of.type !== mo.name) return false;
      const on = of.attrs.match(/@relation\("([^"]+)"/);
      const oName = on ? on[1] : null;
      return relName ? oName === relName : !oName;
    });
    if (!back) continue;
    const backHasFk = /fields:\s*\[/.test(back.attrs);
    if (hasFk && backHasFk) errors.push(`${mo.name}.${f.name} <-> ${other.name}.${back.name}: both sides declare fields[]`);
    if (!hasFk && !backHasFk && !back.list && !f.list)
      warnings.push(`${mo.name}.${f.name} <-> ${other.name}.${back.name}: 1-1 with no fields[] on either side`);
  }
}

/* ---- 5. @id present on every model ---- */
for (const mo of Object.values(models)) {
  if (!/@id/.test(mo.body)) errors.push(`${mo.name}: no @id field`);
}

/* ---- 6. @unique referenced by @@unique/@@index columns exist ---- */
for (const mo of Object.values(models)) {
  const names = new Set(mo.fields.map(f => f.name));
  const re = /@@(?:unique|index)\(\s*\[([^\]]+)\]/g;
  let r;
  while ((r = re.exec(mo.body))) {
    r[1].split(",").map(s => s.trim()).forEach(c => {
      if (c && !names.has(c)) errors.push(`${mo.name}: @@index/@@unique references missing field "${c}"`);
    });
  }
}

/* ---- report ---- */
if (warnings.length) {
  console.log("Warnings:");
  warnings.forEach(w => console.log("  ~ " + w));
  console.log("");
}
if (errors.length) {
  console.log("Errors:");
  errors.forEach(e => console.log("  ✗ " + e));
  console.log(`\n${errors.length} error(s).`);
  process.exit(1);
}
console.log("No structural errors.");

/* ---- inventory ---- */
const rel = [];
for (const mo of Object.values(models))
  for (const f of mo.fields)
    if (models[f.type] && /fields:\s*\[/.test(f.attrs)) rel.push(`${mo.name} -> ${f.type}`);
console.log(`\n${rel.length} foreign-key relations.`);
console.log(`Models: ${modelNames.join(", ")}`);
