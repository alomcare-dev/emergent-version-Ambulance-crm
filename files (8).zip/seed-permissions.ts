/**
 * Role and permission seed.
 *
 * Every entry below is transcribed from a demonstration module that has already
 * been built and reviewed. Nothing here is new policy. Where the demonstrations
 * used a bare permission name inside one module ("view", "edit"), it is
 * namespaced here so the seven sets can live in one table without collision.
 *
 * Read this as the authorisation specification: a server function guards itself
 * by asking for one of these keys, and the answer no longer depends on what the
 * browser chose to render.
 */

import type { RoleKey } from "@prisma/client";
export type { RoleKey };

export const PERMISSIONS: Record<string, string> = {
  // ---- CRM -----------------------------------------------------------------
  "crm.view":                 "See customer accounts",
  "crm.view.own":             "See only the signed-in user's own organisation",
  "crm.create":               "Create a customer account",
  "crm.edit":                 "Amend customer details and contract terms",
  "crm.rates.view":           "See agreed rate cards and charges",
  "crm.rates.edit":           "Amend agreed rates",
  "crm.hold":                 "Place or release a credit hold",
  "crm.activity":             "See and record account activity",
  "crm.activity.own":         "See activity on the user's own organisation only",
  "crm.archive":              "Archive a customer account",
  "crm.audit":                "See the customer change history",

  // ---- Bookings ------------------------------------------------------------
  "booking.view":             "See bookings",
  "booking.view.today":       "See only today's journeys (crew view)",
  "booking.view.own":         "See only the user's own organisation's bookings",
  "booking.create":           "Create a booking",
  "booking.edit":             "Amend a booking",
  "booking.approve":          "Approve a booking awaiting authorisation",
  "booking.price":            "See and override journey pricing",
  "booking.cancel":           "Cancel a booking",
  "booking.status":           "Change a booking's status",
  "booking.request":          "Request a journey through the customer portal",
  "booking.audit":            "See the booking change history",

  // ---- Patients ------------------------------------------------------------
  "patient.view":             "See the patient record",
  "patient.view.transport":   "See only transport-relevant patient detail (driver view)",
  "patient.view.own":         "See only the user's own organisation's patients",
  "patient.edit":             "Amend patient demographics and transport needs",
  "patient.clinical":         "Open the sealed clinical section",
  "patient.clinical.breakglass":     "Break-glass into the clinical section, with a recorded reason",
  "patient.safeguarding":     "Open the sealed safeguarding section",
  "patient.safeguarding.breakglass": "Break-glass into safeguarding, with a recorded reason",
  "patient.alerts":           "See and raise patient alerts",
  "patient.consent":          "Record and withdraw consent",
  "patient.merge":            "Merge duplicate patient records",
  "patient.sar":              "Produce a subject access response",
  "patient.funding":          "See funding and commissioner detail",
  "patient.access.log":       "See who has opened sealed sections",

  // ---- Dispatch ------------------------------------------------------------
  "dispatch.view":            "See the dispatch board",
  "dispatch.view.own":        "See only the user's own vehicle and journeys",
  "dispatch.allocate":        "Allocate and release journeys",
  "dispatch.status":          "Update any journey's status",
  "dispatch.status.own":      "Update status on the user's own journeys",
  "dispatch.message":         "Send and read dispatch messages",
  "dispatch.notes":           "Add control-room notes",
  "dispatch.resources":       "See crew and vehicle availability",
  "dispatch.roster":          "Crew a vehicle and set shift times",
  "dispatch.audit":           "See the dispatch log",

  // ---- Staff ---------------------------------------------------------------
  "staff.view":               "See staff records",
  "staff.view.deployable":    "See only whether a person is deployable, not why",
  "staff.self":               "See and update the user's own record",
  "staff.edit":               "Amend staff records and compliance dates",
  "staff.clinical":           "See professional registration and clinical training",
  "staff.sensitive":          "Open occupational health and disciplinary records",
  "staff.payroll":            "See payroll and National Insurance detail",
  "staff.approve":            "Approve leave and sign off competencies",
  "staff.audit":              "See the staff change history",

  // ---- Fleet ---------------------------------------------------------------
  "fleet.view":               "See vehicle records",
  "fleet.view.deployable":    "See only whether a vehicle may be allocated",
  "fleet.edit":               "Amend vehicles, defects and compliance dates",
  "fleet.check":              "Complete a daily vehicle check",
  "fleet.alerts":             "See renewals and expiry alerts",
  "fleet.audit":              "See the fleet change history",

  // ---- Finance -------------------------------------------------------------
  "finance.view":             "See invoices, credit notes and payments",
  "finance.view.portal":      "See only the user's own organisation's invoices",
  "finance.raise":            "Raise a draft invoice from completed journeys",
  "finance.edit":             "Amend a draft invoice",
  "finance.issue":            "Issue an invoice",
  "finance.credit":           "Raise a credit note",
  "finance.payment":          "Record a payment",
  "finance.remind":           "Send a payment reminder",
  "finance.settings":         "Change the invoice header and organisation detail",
  "finance.export":           "Export finance data",
  "finance.audit":            "See the finance log",
};

/**
 * The matrix. Each role lists exactly the permissions the demonstrations gave
 * it — including the deliberate absences. A dispatcher has no crm.rates.view,
 * so no server function will ever return a rate to them. A paramedic has
 * patient.safeguarding.breakglass but not patient.safeguarding: they can open
 * it, and doing so is recorded.
 */
export const ROLE_PERMISSIONS: Record<RoleKey, string[]> = {
  SUPER_ADMIN: [
    "crm.view","crm.create","crm.edit","crm.rates.view","crm.rates.edit","crm.hold","crm.activity","crm.archive","crm.audit",
    "booking.view","booking.create","booking.edit","booking.approve","booking.price","booking.cancel","booking.status","booking.audit",
    "patient.view","patient.edit","patient.clinical","patient.safeguarding","patient.consent","patient.sar","patient.merge","patient.alerts","patient.access.log",
    "dispatch.view","dispatch.allocate","dispatch.status","dispatch.message","dispatch.notes","dispatch.resources","dispatch.roster","dispatch.audit",
    "staff.view","staff.edit","staff.sensitive","staff.payroll","staff.approve","staff.audit",
    "fleet.view","fleet.edit","fleet.alerts","fleet.audit",
    "finance.view","finance.raise","finance.edit","finance.issue","finance.credit","finance.payment","finance.remind","finance.settings","finance.export","finance.audit",
  ],

  COMPANY_DIRECTOR: [
    "crm.view","crm.create","crm.edit","crm.rates.view","crm.rates.edit","crm.hold","crm.activity","crm.audit",
    "booking.view","booking.create","booking.edit","booking.approve","booking.price","booking.cancel","booking.status","booking.audit",
    "patient.view","patient.clinical","patient.safeguarding","patient.sar","patient.access.log",
    "dispatch.view","dispatch.resources","dispatch.audit",
    "staff.view","staff.audit",
    "fleet.view","fleet.alerts","fleet.audit",
    "finance.view","finance.export","finance.audit",
  ],

  OPERATIONS_MANAGER: [
    "crm.view","crm.create","crm.edit","crm.rates.view","crm.activity","crm.audit",
    "booking.view","booking.create","booking.edit","booking.approve","booking.price","booking.cancel","booking.status","booking.audit",
    "patient.view","patient.edit","patient.clinical","patient.safeguarding","patient.consent","patient.sar","patient.merge","patient.alerts","patient.access.log",
    "dispatch.view","dispatch.allocate","dispatch.status","dispatch.message","dispatch.notes","dispatch.resources","dispatch.roster","dispatch.audit",
    "staff.view","staff.edit","staff.approve","staff.audit",
    "fleet.view","fleet.edit","fleet.alerts","fleet.audit",
    "finance.view","finance.audit",
  ],

  CONTROL_ROOM_DISPATCHER: [
    "crm.view","crm.activity",
    "booking.view","booking.create","booking.edit","booking.cancel","booking.status",
    "patient.view","patient.edit","patient.alerts","patient.clinical.breakglass",
    "dispatch.view","dispatch.allocate","dispatch.status","dispatch.message","dispatch.notes","dispatch.resources",
    "staff.view.deployable","fleet.view.deployable",
  ],

  // Present in the Finance module only. Confirm the intended scope before use —
  // see the open questions note at the foot of this file.
  BOOKING_ADMINISTRATOR: [
    "booking.view","booking.create","booking.edit",
    "patient.view","patient.alerts",
    "finance.view",
  ],

  CLINICAL_LEAD: [
    "crm.view",
    "booking.view","booking.audit",
    "patient.view","patient.clinical","patient.safeguarding","patient.consent","patient.alerts","patient.access.log",
    "dispatch.view","dispatch.message","dispatch.resources","dispatch.audit",
    "staff.view","staff.clinical","staff.approve","fleet.alerts","staff.audit",
  ],

  PARAMEDIC: [
    "booking.view.today",
    "patient.view","patient.clinical","patient.alerts","patient.safeguarding.breakglass",
    "dispatch.view.own","dispatch.status.own","dispatch.message",
    "staff.self",
  ],

  EMERGENCY_MEDICAL_TECHNICIAN: [
    "booking.view.today",
    "patient.view","patient.clinical","patient.alerts",
    "dispatch.view.own","dispatch.status.own","dispatch.message",
    "staff.self",
  ],

  AMBULANCE_CARE_ASSISTANT: [
    "booking.view.today",
    "patient.view","patient.alerts","patient.clinical.breakglass",
    "dispatch.view.own","dispatch.status.own","dispatch.message",
    "staff.self",
  ],

  DRIVER: [
    "booking.view.today",
    "patient.view.transport",
    "dispatch.view.own","dispatch.status.own","dispatch.message",
    "staff.self","fleet.check",
  ],

  EVENT_MEDICAL_STAFF: [
    "booking.view.today",
    "staff.self",
  ],

  HR_COMPLIANCE_OFFICER: [
    "crm.view",
    "staff.view","staff.edit","staff.sensitive","staff.payroll","staff.audit",
    "fleet.view","fleet.alerts","fleet.audit",
  ],

  FLEET_MANAGER: [
    "dispatch.view","dispatch.resources",
    "staff.view",
    "fleet.view","fleet.edit","fleet.alerts","fleet.audit",
  ],

  FINANCE_OFFICER: [
    "crm.view","crm.edit","crm.rates.view","crm.rates.edit","crm.hold","crm.activity","crm.audit",
    "booking.view","booking.price","booking.audit",
    "patient.view","patient.funding",
    "staff.view","staff.payroll",
    "finance.view","finance.raise","finance.edit","finance.issue","finance.credit","finance.payment","finance.remind","finance.settings","finance.export","finance.audit",
  ],

  QUALITY_ASSURANCE_OFFICER: [
    "crm.view","crm.activity","crm.audit",
    "booking.view","booking.audit",
    "patient.view","patient.clinical","patient.safeguarding","patient.sar","patient.access.log",
    "dispatch.view","dispatch.audit",
    "staff.view","staff.audit",
    "fleet.view","fleet.alerts","fleet.audit",
    "finance.view","finance.audit",
  ],

  PORTAL_USER: [
    "crm.view.own","crm.activity.own",
    "booking.view.own","booking.request",
    "patient.view.own",
    "finance.view.portal",
  ],
};

export const ROLE_NAMES: Record<RoleKey, string> = {
  SUPER_ADMIN:                  "Super Administrator",
  COMPANY_DIRECTOR:             "Company Director",
  OPERATIONS_MANAGER:           "Operations Manager",
  CONTROL_ROOM_DISPATCHER:      "Control Room Dispatcher",
  BOOKING_ADMINISTRATOR:        "Booking Administrator",
  CLINICAL_LEAD:                "Clinical Lead",
  PARAMEDIC:                    "Paramedic",
  EMERGENCY_MEDICAL_TECHNICIAN: "Emergency Medical Technician",
  AMBULANCE_CARE_ASSISTANT:     "Ambulance Care Assistant",
  DRIVER:                       "Driver",
  EVENT_MEDICAL_STAFF:          "Event Medical Staff",
  HR_COMPLIANCE_OFFICER:        "HR & Compliance Officer",
  FLEET_MANAGER:                "Fleet Manager",
  FINANCE_OFFICER:              "Finance Officer",
  QUALITY_ASSURANCE_OFFICER:    "Quality Assurance Officer",
  PORTAL_USER:                  "Commissioner / Customer Portal User",
};

/* ---------------------------------------------------------------------------
   Open questions for review — carried forward rather than decided silently.

   1. BOOKING_ADMINISTRATOR appears in the Finance module only; the other six
      modules define fifteen roles without it. Either it is a sixteenth role
      that needs a full permission set agreed, or it should be folded into
      CONTROL_ROOM_DISPATCHER. Flagged, not resolved.

   2. FINANCE_OFFICER holds staff.payroll here because the Finance module
      granted it. Confirm that finance should see payroll detail, or move it
      behind a separate payroll role.

   3. Break-glass currently has no time limit. The demonstrations reset it on
      role switch, which has no production equivalent. A session-scoped or
      shift-scoped expiry should be agreed before build.
--------------------------------------------------------------------------- */
