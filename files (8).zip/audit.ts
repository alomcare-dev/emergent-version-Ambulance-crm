/**
 * Audit.
 *
 * One append-only table for the whole system (decision 1 in the schema). This
 * module is the only sanctioned way to write to it: there is no update and no
 * delete, and the actor label is captured at the time so history survives a
 * member of staff leaving.
 *
 * Two rules the demonstrations could only honour by convention, and which are
 * enforced here:
 *
 *   - The audit write happens in the same transaction as the change it
 *     describes. An allocation that succeeded but was not audited is worse
 *     than one that failed.
 *   - Reading a sealed section writes an audit row *before* the data is
 *     returned, not after. If the write fails, the read does not happen.
 */

import type { Session, SealedSection } from "../authz/authz.ts";

export type EntityType =
  | "CUSTOMER" | "PATIENT" | "BOOKING" | "ALLOCATION" | "STAFF"
  | "VEHICLE" | "INVOICE" | "CREDIT_NOTE" | "PAYMENT" | "USER" | "DOCUMENT";

export interface AuditInput {
  entityType: EntityType;
  entityId: string;
  action: string;
  detail?: string;
  metadata?: Record<string, unknown>;
}

/** The row shape written to AuditEvent. */
export interface AuditRow extends AuditInput {
  occurredAt: Date;
  actorId: string | null;
  actorLabel: string;
}

/**
 * Build the row. Kept separate from writing it so the shape can be tested
 * without a database, and so callers inside a transaction can hand the row to
 * whichever client they are already holding.
 */
export function buildAuditRow(
  session: Session | null,
  input: AuditInput,
  now: Date = new Date(),
): AuditRow {
  return {
    ...input,
    occurredAt: now,
    actorId: session?.userId ?? null,
    // Denormalised deliberately: "R. Ahmadi (Paramedic)" stays readable years
    // later even if the user record is deleted or the role changes.
    actorLabel: session
      ? `${session.displayName} (${session.roles.join(", ")})`
      : "System",
  };
}

/** Minimal shape of the Prisma client this module needs. */
export interface AuditClient {
  auditEvent: { create(args: { data: AuditRow }): Promise<unknown> };
  patientAccessLog: {
    create(args: {
      data: {
        patientId: string;
        userId: string;
        userLabel: string;
        section: SealedSection;
        reason: string;
        jobRef?: string;
        occurredAt: Date;
      };
    }): Promise<unknown>;
  };
}

export async function writeAudit(
  client: AuditClient,
  session: Session | null,
  input: AuditInput,
  now: Date = new Date(),
): Promise<void> {
  await client.auditEvent.create({ data: buildAuditRow(session, input, now) });
}

/**
 * Record a break-glass release.
 *
 * Writes twice on purpose: once to the patient's own access log, which is what
 * the patient would be shown under a subject access request, and once to the
 * org-wide audit, which is what an information-governance review reads. They
 * serve different readers and both are required.
 *
 * Returns nothing useful — the caller proceeds only if this resolves.
 */
export async function recordBreakGlass(
  client: AuditClient,
  session: Session,
  args: { patientId: string; section: SealedSection; reason: string; jobRef?: string },
  now: Date = new Date(),
): Promise<void> {
  const label = `${session.displayName} (${session.roles.join(", ")})`;

  await client.patientAccessLog.create({
    data: {
      patientId: args.patientId,
      userId: session.userId,
      userLabel: label,
      section: args.section,
      reason: args.reason,
      jobRef: args.jobRef,
      occurredAt: now,
    },
  });

  await writeAudit(
    client,
    session,
    {
      entityType: "PATIENT",
      entityId: args.patientId,
      action: "Break-glass access",
      detail: `${args.section.toLowerCase()} section opened — ${args.reason}`,
      metadata: { section: args.section, jobRef: args.jobRef ?? null },
    },
    now,
  );
}
