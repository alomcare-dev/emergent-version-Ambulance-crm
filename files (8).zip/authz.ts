/**
 * Authorisation.
 *
 * The demonstrations proved the permission model with a dropdown. This is the
 * same model with the dropdown removed: the session is established at sign-in,
 * cannot be changed by the client, and every server function asks this module
 * before it acts.
 *
 * The important thing this file gets right, which a boolean permission check
 * would get wrong: authorisation here has three dimensions, not one.
 *
 *   1. May they perform the action at all?      -> can()
 *   2. Which rows may they see?                 -> rowScope()      (scope.ts)
 *   3. Which fields of those rows?              -> fieldScope()    (scope.ts)
 *
 * The demonstrations' permission names already encode this. "booking.view" and
 * "booking.view.today" are not two levels of the same right — the second is a
 * row filter. "patient.view" and "patient.view.transport" differ by which
 * columns come back. Collapsing all of that into can() would produce a system
 * that answers "yes" and then hands over the whole table.
 */

import { ROLE_PERMISSIONS } from "../../prisma/seed-permissions.ts";
import type { RoleKey } from "../../prisma/seed-permissions.ts";

/** Established at sign-in from the database. Never trusted from the client. */
export interface Session {
  userId: string;
  displayName: string;
  roles: RoleKey[];
  /** Flattened union of every role's permissions. Computed, not stored. */
  permissions: ReadonlySet<string>;
  /** Set when the user is linked to a staff record — drives "own vehicle" scoping. */
  staffId?: string;
  /** Set for portal users — drives "own organisation" scoping. */
  customerId?: string;
  expiresAt: Date;
}

/** A recorded break-glass access, read back from PatientAccessLog. */
export interface BreakGlassAccess {
  userId: string;
  patientId: string;
  section: SealedSection;
  occurredAt: Date;
}

export type SealedSection = "CLINICAL" | "SAFEGUARDING";

/**
 * How long a break-glass release stays open.
 *
 * This settles one of the three questions left open in seed-permissions.ts.
 * The demonstrations reset the grant when the role switcher changed, which has
 * no production equivalent. A shift is the natural unit: the clinical reason
 * for opening a record is the journey in front of the user, and that journey
 * ends when their shift does. Eight hours, and tied to one patient and one
 * section — never a blanket elevation.
 */
export const BREAK_GLASS_WINDOW_MS = 8 * 60 * 60 * 1000;

export class AuthorisationError extends Error {
  readonly status = 403;
  readonly permission: string;
  readonly detail?: string;

  constructor(permission: string, detail?: string) {
    super(
      detail
        ? `Not permitted: ${permission} — ${detail}`
        : `Not permitted: ${permission}`,
    );
    this.name = "AuthorisationError";
    this.permission = permission;
    this.detail = detail;
  }
}

export class AuthenticationError extends Error {
  readonly status = 401;
  constructor(message = "Not signed in") {
    super(message);
    this.name = "AuthenticationError";
  }
}

/** Build the permission set for a set of roles. Union, never intersection. */
export function permissionsFor(roles: RoleKey[]): ReadonlySet<string> {
  const out = new Set<string>();
  for (const r of roles) {
    for (const p of ROLE_PERMISSIONS[r] ?? []) out.add(p);
  }
  return out;
}

/** Does this session hold the permission outright? */
export function can(session: Session | null, permission: string): boolean {
  if (!session) return false;
  if (session.expiresAt.getTime() <= Date.now()) return false;
  return session.permissions.has(permission);
}

/** Does the session hold any one of these? Used where several roles qualify. */
export function canAny(session: Session | null, ...permissions: string[]): boolean {
  return permissions.some((p) => can(session, p));
}

/**
 * The guard every server function starts with. Throws rather than returning
 * false, so a forgotten check fails loudly instead of silently proceeding.
 */
export function requirePermission(
  session: Session | null,
  permission: string,
  detail?: string,
): asserts session is Session {
  if (!session) throw new AuthenticationError();
  if (session.expiresAt.getTime() <= Date.now()) {
    throw new AuthenticationError("Session has expired");
  }
  if (!session.permissions.has(permission)) {
    throw new AuthorisationError(permission, detail);
  }
}

/* ---------------------------------------------------------------------------
   Break-glass
--------------------------------------------------------------------------- */

/**
 * May this session read a sealed section of this patient, right now?
 *
 * Three ways to qualify, in order of preference:
 *   - standing permission (a clinical lead has patient.clinical outright)
 *   - an open break-glass release for this patient and this section
 *   - not at all
 *
 * Note what is deliberately absent: there is no way to answer "yes" without
 * either a standing grant or a recorded access. The audit row *is* the grant —
 * see openGrantExists below — so an active elevation that was never audited
 * cannot exist. That property is worth more than a separate grants table.
 */
export function canReadSealed(
  session: Session | null,
  section: SealedSection,
  patientId: string,
  recentAccesses: readonly BreakGlassAccess[],
  now: Date = new Date(),
): boolean {
  if (!session) return false;

  const standing = section === "CLINICAL" ? "patient.clinical" : "patient.safeguarding";
  if (can(session, standing)) return true;

  const viaGlass =
    section === "CLINICAL"
      ? "patient.clinical.breakglass"
      : "patient.safeguarding.breakglass";
  if (!can(session, viaGlass)) return false;

  return openGrantExists(session.userId, patientId, section, recentAccesses, now);
}

/** May this session break glass into this section — i.e. should the modal appear? */
export function canBreakGlass(session: Session | null, section: SealedSection): boolean {
  const viaGlass =
    section === "CLINICAL"
      ? "patient.clinical.breakglass"
      : "patient.safeguarding.breakglass";
  return can(session, viaGlass);
}

/**
 * An access recorded within the window counts as an open grant.
 * Scoped to one user, one patient, one section — never wider.
 */
export function openGrantExists(
  userId: string,
  patientId: string,
  section: SealedSection,
  accesses: readonly BreakGlassAccess[],
  now: Date = new Date(),
): boolean {
  const floor = now.getTime() - BREAK_GLASS_WINDOW_MS;
  return accesses.some(
    (a) =>
      a.userId === userId &&
      a.patientId === patientId &&
      a.section === section &&
      a.occurredAt.getTime() > floor &&
      a.occurredAt.getTime() <= now.getTime(),
  );
}

/** What a caller must supply to break glass. Both are mandatory. */
export interface BreakGlassRequest {
  patientId: string;
  section: SealedSection;
  reason: string;
  jobRef?: string;
}

export function validateBreakGlass(req: BreakGlassRequest): string[] {
  const problems: string[] = [];
  if (!req.reason || req.reason.trim().length < 10) {
    problems.push("Give a reason of at least ten characters.");
  }
  if (!req.patientId) problems.push("No patient identified.");
  return problems;
}
