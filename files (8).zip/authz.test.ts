import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

import { ROLE_PERMISSIONS, ROLE_NAMES, PERMISSIONS } from "../../prisma/seed-permissions.ts";
import type { RoleKey } from "../../prisma/seed-permissions.ts";
import {
  can, canAny, requirePermission, permissionsFor,
  canReadSealed, canBreakGlass, openGrantExists, validateBreakGlass,
  AuthorisationError, AuthenticationError, BREAK_GLASS_WINDOW_MS,
  type Session, type BreakGlassAccess,
} from "./authz.ts";
import {
  bookingScope, patientScope, customerScope, staffScope, invoiceScope,
  patientFields, staffFields, includePricing,
} from "./scope.ts";
import { buildAuditRow, recordBreakGlass, type AuditClient } from "../audit/audit.ts";

/* ---------- helpers ---------- */
function sessionFor(roles: RoleKey[], extra: Partial<Session> = {}): Session {
  return {
    userId: "u1",
    displayName: "Test User",
    roles,
    permissions: permissionsFor(roles),
    expiresAt: new Date(Date.now() + 3600_000),
    ...extra,
  };
}
const NOW = new Date("2026-07-24T09:00:00Z");

/* =====================================================================
   The seed must match the schema. This is the drift that broke the demos.
   ===================================================================== */
describe("seed matches schema", () => {
  const schema = readFileSync(new URL("../../prisma/schema.prisma", import.meta.url), "utf8");
  const enumBlock = schema.match(/enum RoleKey \{([\s\S]*?)\}/);

  test("RoleKey enum exists in the schema", () => {
    assert.ok(enumBlock, "no RoleKey enum found");
  });

  test("every schema role has a permission set and a name", () => {
    const schemaRoles = enumBlock![1]
      .split("\n").map((l) => l.trim()).filter((l) => l && !l.startsWith("//"));
    for (const r of schemaRoles) {
      assert.ok(r in ROLE_PERMISSIONS, `${r} has no permission set`);
      assert.ok(r in ROLE_NAMES, `${r} has no display name`);
    }
    assert.equal(schemaRoles.length, Object.keys(ROLE_PERMISSIONS).length,
      "schema and seed disagree on how many roles exist");
  });

  test("every granted permission is declared", () => {
    for (const [role, perms] of Object.entries(ROLE_PERMISSIONS)) {
      for (const p of perms) {
        assert.ok(p in PERMISSIONS, `${role} granted undeclared permission ${p}`);
      }
    }
  });
});

/* =====================================================================
   can / requirePermission
   ===================================================================== */
describe("can()", () => {
  test("grants what the role holds", () => {
    const s = sessionFor(["FINANCE_OFFICER"]);
    assert.equal(can(s, "finance.issue"), true);
    assert.equal(can(s, "crm.rates.view"), true);
  });

  test("refuses what the role does not hold", () => {
    const s = sessionFor(["CONTROL_ROOM_DISPATCHER"]);
    assert.equal(can(s, "crm.rates.view"), false, "a dispatcher must never see rates");
    assert.equal(can(s, "finance.issue"), false);
    assert.equal(can(s, "patient.safeguarding"), false);
  });

  test("refuses everything for a null session", () => {
    assert.equal(can(null, "booking.view"), false);
  });

  test("refuses everything once the session has expired", () => {
    const s = sessionFor(["SUPER_ADMIN"], { expiresAt: new Date(Date.now() - 1000) });
    assert.equal(can(s, "booking.view"), false, "an expired session must grant nothing");
  });

  test("multiple roles union, never intersect", () => {
    const s = sessionFor(["DRIVER", "FLEET_MANAGER"]);
    assert.equal(can(s, "fleet.check"), true);   // from driver
    assert.equal(can(s, "fleet.edit"), true);    // from fleet manager
  });

  test("canAny", () => {
    const s = sessionFor(["PARAMEDIC"]);
    assert.equal(canAny(s, "patient.safeguarding", "patient.safeguarding.breakglass"), true);
    assert.equal(canAny(s, "finance.issue", "crm.rates.edit"), false);
  });
});

describe("requirePermission()", () => {
  test("passes silently when held", () => {
    const s = sessionFor(["OPERATIONS_MANAGER"]);
    assert.doesNotThrow(() => requirePermission(s, "dispatch.allocate"));
  });

  test("throws AuthorisationError when not held", () => {
    const s = sessionFor(["DRIVER"]);
    assert.throws(() => requirePermission(s, "dispatch.allocate"), AuthorisationError);
  });

  test("throws AuthenticationError when not signed in", () => {
    assert.throws(() => requirePermission(null, "booking.view"), AuthenticationError);
  });

  test("error carries the permission for the audit trail", () => {
    const s = sessionFor(["DRIVER"]);
    try {
      requirePermission(s, "finance.issue", "tried to issue INV-1001");
      assert.fail("should have thrown");
    } catch (e) {
      assert.ok(e instanceof AuthorisationError);
      assert.equal(e.permission, "finance.issue");
      assert.equal(e.status, 403);
      assert.match(e.message, /INV-1001/);
    }
  });
});

/* =====================================================================
   Break-glass
   ===================================================================== */
describe("break-glass", () => {
  const patientId = "p1";
  const glassAccess = (mins: number, userId = "u1"): BreakGlassAccess => ({
    userId, patientId, section: "CLINICAL",
    occurredAt: new Date(NOW.getTime() - mins * 60_000),
  });

  test("standing permission needs no glass", () => {
    const s = sessionFor(["CLINICAL_LEAD"]);
    assert.equal(canReadSealed(s, "CLINICAL", patientId, [], NOW), true);
  });

  test("a role with neither standing nor glass is refused", () => {
    const s = sessionFor(["FLEET_MANAGER"]);
    assert.equal(canReadSealed(s, "CLINICAL", patientId, [], NOW), false);
  });

  test("glass-capable role is refused until it actually breaks glass", () => {
    const s = sessionFor(["AMBULANCE_CARE_ASSISTANT"]);
    assert.equal(canBreakGlass(s, "CLINICAL"), true, "the option should be offered");
    assert.equal(canReadSealed(s, "CLINICAL", patientId, [], NOW), false,
      "offering the option is not the same as granting access");
  });

  test("a recorded access opens the section", () => {
    const s = sessionFor(["AMBULANCE_CARE_ASSISTANT"]);
    assert.equal(canReadSealed(s, "CLINICAL", patientId, [glassAccess(5)], NOW), true);
  });

  test("the grant expires after the window", () => {
    const s = sessionFor(["AMBULANCE_CARE_ASSISTANT"]);
    const stale = BREAK_GLASS_WINDOW_MS / 60_000 + 1;
    assert.equal(canReadSealed(s, "CLINICAL", patientId, [glassAccess(stale)], NOW), false);
  });

  test("the grant is scoped to one patient", () => {
    const s = sessionFor(["AMBULANCE_CARE_ASSISTANT"]);
    const other: BreakGlassAccess = { ...glassAccess(5), patientId: "p2" };
    assert.equal(canReadSealed(s, "CLINICAL", patientId, [other], NOW), false,
      "breaking glass on one patient must not open another");
  });

  test("the grant is scoped to one section", () => {
    const s = sessionFor(["PARAMEDIC"]);
    // paramedic has standing clinical, glass for safeguarding
    const clinicalOnly = [glassAccess(5)];
    assert.equal(canReadSealed(s, "SAFEGUARDING", patientId, clinicalOnly, NOW), false,
      "a clinical release must not open safeguarding");
  });

  test("the grant is scoped to one user", () => {
    const s = sessionFor(["AMBULANCE_CARE_ASSISTANT"]);
    assert.equal(
      canReadSealed(s, "CLINICAL", patientId, [glassAccess(5, "someone-else")], NOW),
      false, "one user's release must not cover another");
  });

  test("a future-dated access does not count", () => {
    const s = sessionFor(["AMBULANCE_CARE_ASSISTANT"]);
    const future: BreakGlassAccess = { ...glassAccess(0), occurredAt: new Date(NOW.getTime() + 60_000) };
    assert.equal(openGrantExists("u1", patientId, "CLINICAL", [future], NOW), false);
  });

  test("a reason is required and must be substantive", () => {
    assert.deepEqual(validateBreakGlass({ patientId, section: "CLINICAL", reason: "" }).length, 1);
    assert.deepEqual(validateBreakGlass({ patientId, section: "CLINICAL", reason: "because" }).length, 1);
    assert.deepEqual(
      validateBreakGlass({ patientId, section: "CLINICAL", reason: "Patient deteriorating en route" }),
      []);
  });
});

/* =====================================================================
   Row scoping
   ===================================================================== */
describe("row scope", () => {
  test("full permission sees everything", () => {
    assert.deepEqual(bookingScope(sessionFor(["OPERATIONS_MANAGER"]), NOW), {});
  });

  test("no permission sees nothing", () => {
    assert.equal(bookingScope(sessionFor(["HR_COMPLIANCE_OFFICER"]), NOW), false);
  });

  test("crew are limited to today and to their own vehicle", () => {
    const s = sessionFor(["DRIVER"], { staffId: "s4" });
    const scope = bookingScope(s, NOW) as Record<string, any>;
    assert.ok(scope.collectDate, "must be limited to a date");
    assert.equal(
      scope.allocation.vehicle.crewAssignments.some.staffId, "s4",
      "must be limited to the vehicle they are crewed on");
  });

  test("crew with no staff record see nothing, not everything", () => {
    const s = sessionFor(["DRIVER"]); // no staffId
    assert.equal(bookingScope(s, NOW), false,
      "a missing link must fail closed");
  });

  test("portal users are limited to their own organisation", () => {
    const s = sessionFor(["PORTAL_USER"], { customerId: "c1" });
    assert.deepEqual(bookingScope(s, NOW), { customerId: "c1" });
    assert.deepEqual(customerScope(s), { id: "c1" });
  });

  test("portal users with no organisation see nothing", () => {
    assert.equal(bookingScope(sessionFor(["PORTAL_USER"]), NOW), false);
  });

  test("portal users never see draft invoices", () => {
    const s = sessionFor(["PORTAL_USER"], { customerId: "c1" });
    const scope = invoiceScope(s) as Record<string, any>;
    assert.deepEqual(scope.status, { not: "DRAFT" });
  });

  test("crew self-service is limited to their own staff record", () => {
    const s = sessionFor(["PARAMEDIC"], { staffId: "s3" });
    assert.deepEqual(staffScope(s), { id: "s3" });
  });

  test("a driver reaches a patient only through a journey they carry", () => {
    const s = sessionFor(["DRIVER"], { staffId: "s4" });
    const scope = patientScope(s) as Record<string, any>;
    assert.ok(scope.bookings?.some, "must be reached via a booking");
  });
});

/* =====================================================================
   Field scoping
   ===================================================================== */
describe("field scope", () => {
  test("a driver gets transport fields but no clinical, funding or next of kin", () => {
    const s = sessionFor(["DRIVER"], { staffId: "s4" });
    const f = patientFields(s, { clinical: false, safeguarding: false });
    assert.ok(f.mobility, "needs mobility");
    assert.ok(f.alerts, "needs alerts");
    assert.equal(f.clinical, undefined);
    assert.equal(f.funding, undefined);
    assert.equal(f.nokPhone, undefined, "next of kin is not a driver's business");
  });

  test("sealed tables are absent unless the caller qualified", () => {
    const s = sessionFor(["AMBULANCE_CARE_ASSISTANT"]);
    const closed = patientFields(s, { clinical: false, safeguarding: false });
    assert.equal(closed.clinical, undefined, "must not be selected at all");

    const open = patientFields(s, { clinical: true, safeguarding: false });
    assert.equal(open.clinical, true);
    assert.equal(open.safeguarding, undefined);
  });

  test("a dispatcher sees deployability but not compliance detail", () => {
    const s = sessionFor(["CONTROL_ROOM_DISPATCHER"]);
    const f = staffFields(s);
    assert.ok(f.grade);
    assert.equal(f.complianceItems, undefined, "dates are health-adjacent");
    assert.equal(f.payrollRef, undefined);
  });

  test("HR sees payroll and occupational health; a fleet manager does not", () => {
    const hr = staffFields(sessionFor(["HR_COMPLIANCE_OFFICER"]));
    assert.equal(hr.payrollRef, true);
    assert.equal(hr.occupationalHealth, true);

    const fleet = staffFields(sessionFor(["FLEET_MANAGER"]));
    assert.equal(fleet.occupationalHealth, undefined);
    assert.equal(fleet.payrollRef, undefined);
  });

  test("a clinical lead sees registrations, not the whole compliance set", () => {
    const f = staffFields(sessionFor(["CLINICAL_LEAD"])) as Record<string, any>;
    assert.ok(f.complianceItems?.where, "should be filtered, not wholesale");
  });

  test("pricing is visible only to roles that hold it", () => {
    assert.equal(includePricing(sessionFor(["FINANCE_OFFICER"])), true);
    assert.equal(includePricing(sessionFor(["OPERATIONS_MANAGER"])), true);
    assert.equal(includePricing(sessionFor(["CONTROL_ROOM_DISPATCHER"])), false);
    assert.equal(includePricing(sessionFor(["PARAMEDIC"])), false);
  });
});

/* =====================================================================
   Audit
   ===================================================================== */
describe("audit", () => {
  test("captures the actor label at the time", () => {
    const s = sessionFor(["PARAMEDIC"], { displayName: "R. Ahmadi" });
    const row = buildAuditRow(s, { entityType: "BOOKING", entityId: "b1", action: "Status update" }, NOW);
    assert.equal(row.actorLabel, "R. Ahmadi (PARAMEDIC)");
    assert.equal(row.actorId, "u1");
    assert.equal(row.occurredAt, NOW);
  });

  test("system actions are attributable", () => {
    const row = buildAuditRow(null, { entityType: "INVOICE", entityId: "i1", action: "Overdue" }, NOW);
    assert.equal(row.actorLabel, "System");
    assert.equal(row.actorId, null);
  });

  test("break-glass writes to both the patient log and the org audit", async () => {
    const calls: string[] = [];
    const client: AuditClient = {
      auditEvent: { create: async () => { calls.push("audit"); return {}; } },
      patientAccessLog: { create: async () => { calls.push("patient"); return {}; } },
    };
    const s = sessionFor(["AMBULANCE_CARE_ASSISTANT"], { displayName: "L. Corrigan" });
    await recordBreakGlass(client, s,
      { patientId: "p1", section: "CLINICAL", reason: "Patient deteriorating", jobRef: "JOB-00011" }, NOW);
    assert.deepEqual(calls, ["patient", "audit"],
      "the patient's own log is written first");
  });

  test("if the audit write fails the caller does not proceed", async () => {
    const client: AuditClient = {
      auditEvent: { create: async () => { throw new Error("db down"); } },
      patientAccessLog: { create: async () => ({}) },
    };
    const s = sessionFor(["AMBULANCE_CARE_ASSISTANT"]);
    await assert.rejects(
      () => recordBreakGlass(client, s, { patientId: "p1", section: "CLINICAL", reason: "x" }, NOW),
      /db down/);
  });
});
