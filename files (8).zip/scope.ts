/**
 * Row and field scoping.
 *
 * Half the permissions in the matrix are not yes/no — they are "yes, but only
 * these rows" or "yes, but only these columns". This module turns them into
 * Prisma fragments, so the narrowing happens in the query rather than in the
 * browser.
 *
 * The rule this enforces: if a role cannot see something, the server does not
 * fetch it. The demonstrations had no choice but to fetch everything and hide
 * the difference in the client, which protects nobody.
 */

import { can, type Session } from "./authz.ts";

/** A Prisma `where` fragment. `false` means "no rows at all". */
export type RowScope = Record<string, unknown> | false;

const NOTHING: RowScope = false;
const EVERYTHING: RowScope = {};

const startOfToday = (now: Date) =>
  new Date(now.getFullYear(), now.getMonth(), now.getDate());
const endOfToday = (now: Date) => {
  const d = startOfToday(now);
  d.setDate(d.getDate() + 1);
  return d;
};

/* ---------------------------------------------------------------------------
   Bookings
--------------------------------------------------------------------------- */

export function bookingScope(session: Session | null, now: Date = new Date()): RowScope {
  if (!session) return NOTHING;

  if (can(session, "booking.view")) return EVERYTHING;

  // Crew: today's journeys on the vehicle they are crewed to. Not "all of
  // today's journeys" — a driver has no business seeing another crew's list.
  if (can(session, "booking.view.today")) {
    if (!session.staffId) return NOTHING;
    return {
      collectDate: { gte: startOfToday(now), lt: endOfToday(now) },
      allocation: {
        vehicle: {
          crewAssignments: {
            some: {
              staffId: session.staffId,
              shiftDate: { gte: startOfToday(now), lt: endOfToday(now) },
            },
          },
        },
      },
    };
  }

  // Portal: the signed-in organisation's own bookings.
  if (can(session, "booking.view.own")) {
    if (!session.customerId) return NOTHING;
    return { customerId: session.customerId };
  }

  return NOTHING;
}

/* ---------------------------------------------------------------------------
   Patients
--------------------------------------------------------------------------- */

export function patientScope(session: Session | null): RowScope {
  if (!session) return NOTHING;
  if (can(session, "patient.view")) return EVERYTHING;

  // A driver sees a patient only through a journey they are carrying.
  if (can(session, "patient.view.transport")) {
    if (!session.staffId) return NOTHING;
    return {
      bookings: {
        some: {
          allocation: {
            vehicle: { crewAssignments: { some: { staffId: session.staffId } } },
          },
        },
      },
    };
  }

  if (can(session, "patient.view.own")) {
    if (!session.customerId) return NOTHING;
    return { bookings: { some: { customerId: session.customerId } } };
  }

  return NOTHING;
}

/* ---------------------------------------------------------------------------
   Customers, staff, vehicles, invoices
--------------------------------------------------------------------------- */

export function customerScope(session: Session | null): RowScope {
  if (!session) return NOTHING;
  if (can(session, "crm.view")) return EVERYTHING;
  if (can(session, "crm.view.own")) {
    return session.customerId ? { id: session.customerId } : NOTHING;
  }
  return NOTHING;
}

export function staffScope(session: Session | null): RowScope {
  if (!session) return NOTHING;
  if (can(session, "staff.view") || can(session, "staff.view.deployable")) return EVERYTHING;
  // Self-service: crew see their own record and no other.
  if (can(session, "staff.self")) {
    return session.staffId ? { id: session.staffId } : NOTHING;
  }
  return NOTHING;
}

export function vehicleScope(session: Session | null): RowScope {
  if (!session) return NOTHING;
  if (can(session, "fleet.view") || can(session, "fleet.view.deployable")) return EVERYTHING;
  if (can(session, "fleet.check")) return EVERYTHING; // a driver may check any vehicle
  return NOTHING;
}

export function invoiceScope(session: Session | null): RowScope {
  if (!session) return NOTHING;
  if (can(session, "finance.view")) return EVERYTHING;
  if (can(session, "finance.view.portal")) {
    if (!session.customerId) return NOTHING;
    // A portal user never sees a draft: it is not yet a claim on them.
    return { customerId: session.customerId, status: { not: "DRAFT" } };
  }
  return NOTHING;
}

/* ---------------------------------------------------------------------------
   Field scoping
--------------------------------------------------------------------------- */

/** A Prisma `select` fragment. */
export type FieldScope = Record<string, unknown>;

const PATIENT_IDENTITY = {
  id: true,
  ref: true,
  surname: true,
  forename: true,
  preferredName: true,
  dateOfBirth: true,
  nhsNumber: true,
  status: true,
} as const;

const PATIENT_TRANSPORT = {
  mobility: true,
  wheelchairNotes: true,
  handlingNotes: true,
  ipcStatus: true,
  accessNotes: true,
  commsNeeds: true,
  commsMethod: true,
  addressLine: true,
  postcode: true,
  phone: true,
  mobile: true,
} as const;

/**
 * What to select for a patient.
 *
 * `sealedClinical` and `sealedSafeguarding` are decided per patient by
 * canReadSealed(), because break-glass is per patient — so they arrive as
 * arguments rather than being derived from the session alone.
 */
export function patientFields(
  session: Session | null,
  opts: { clinical: boolean; safeguarding: boolean },
): FieldScope {
  if (!session) return {};

  // Driver: identity and what is needed to carry the person safely. No
  // funding, no next of kin, no clinical, no safeguarding.
  if (can(session, "patient.view.transport") && !can(session, "patient.view")) {
    return {
      ...PATIENT_IDENTITY,
      ...PATIENT_TRANSPORT,
      alerts: { where: { isActive: true }, select: { kind: true, text: true } },
    };
  }

  const base: FieldScope = {
    ...PATIENT_IDENTITY,
    ...PATIENT_TRANSPORT,
    nokRelationship: true,
    nokPhone: true,
    emergencyRelationship: true,
    emergencyPhone: true,
    gpName: true,
    gpPractice: true,
    gpPhone: true,
    hospitalName: true,
    hospitalNumber: true,
    ward: true,
    alerts: true,
    consents: can(session, "patient.consent") || can(session, "patient.view"),
  };

  if (can(session, "patient.funding")) {
    base.funding = true;
    base.commissioner = true;
  }

  // The sealed tables are simply not joined unless the caller qualified.
  if (opts.clinical) base.clinical = true;
  if (opts.safeguarding) base.safeguarding = true;

  return base;
}

/** What to select for a staff record. */
export function staffFields(session: Session | null): FieldScope {
  if (!session) return {};

  const base: FieldScope = {
    id: true,
    ref: true,
    forename: true,
    surname: true,
    grade: true,
    status: true,
    baseLocation: true,
  };

  // A dispatcher needs to know whether someone may be crewed, not why not.
  // Compliance dates are health-adjacent and none of a dispatcher's business.
  if (can(session, "staff.view.deployable") && !can(session, "staff.view")) {
    return base;
  }

  base.employment = true;
  base.startDate = true;
  base.phone = true;
  base.email = true;
  base.drivingCategories = true;
  base.workingRestrictions = true;
  base.complianceItems = true;
  base.competencies = true;
  base.trainingRecords = true;

  if (can(session, "staff.clinical")) {
    base.complianceItems = {
      where: { item: { in: ["PROFESSIONAL_REGISTRATION", "BASIC_LIFE_SUPPORT", "SAFEGUARDING"] } },
    };
  }
  if (can(session, "staff.payroll")) {
    base.payrollRef = true;
  }
  if (can(session, "staff.sensitive")) {
    base.occupationalHealth = true;
    base.emergencyRelationship = true;
    base.emergencyPhone = true;
  }
  if (can(session, "staff.approve") || can(session, "staff.edit")) {
    base.leaveRequests = true;
    base.appraisals = true;
  }

  return base;
}

/** Whether pricing may appear on a booking at all. */
export function includePricing(session: Session | null): boolean {
  return can(session, "booking.price") || can(session, "crm.rates.view");
}
